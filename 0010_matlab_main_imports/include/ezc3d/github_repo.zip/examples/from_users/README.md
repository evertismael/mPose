Hi all!

You will find here a collection of examples sent to me by (what I hope!) are satisfied users of ezc3d!

Many thanks to:
redcat22 that provided a python btk-like interface that facilitates the transition to ezc3d :)
